package udla.schiribogamdamian.system;

import javax.swing.*;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Hotel plazagrande = new Hotel();
        boolean continuar = true;
        while (continuar) {
            plazagrande.iniciarSistema();
            int continuar1 = Integer.parseInt(JOptionPane.showInputDialog(null, "¿Deseas continuar en el sistema? 1. Sí 2.No "));
            if (continuar1 == 2) {
                continuar = false;
                JOptionPane.showMessageDialog(null, "Saliendo del sistema. ¡Gracias por usar Plaza Grande!");
            }
        }
    }
}